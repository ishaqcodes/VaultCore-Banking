package com.login.loginBackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginBackendApplication.class, args);
	}

}
