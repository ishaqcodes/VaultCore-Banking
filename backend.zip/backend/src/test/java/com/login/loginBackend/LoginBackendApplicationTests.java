package com.login.loginBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
